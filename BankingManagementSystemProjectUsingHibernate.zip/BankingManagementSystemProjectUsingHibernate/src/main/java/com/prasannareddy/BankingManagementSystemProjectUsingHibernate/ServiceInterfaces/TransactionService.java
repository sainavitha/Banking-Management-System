package com.prasannareddy.BankingManagementSystemProjectUsingHibernate.ServiceInterfaces;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.Entites.Transaction;
public interface TransactionService {
	void createTransaction(Transaction transaction);
    Transaction readTransaction(int transactionId);
    void updateTransaction(Transaction transaction);
    void deleteTransaction(int transactionId);
	Transaction getTransactionById(int transactionId);
}
