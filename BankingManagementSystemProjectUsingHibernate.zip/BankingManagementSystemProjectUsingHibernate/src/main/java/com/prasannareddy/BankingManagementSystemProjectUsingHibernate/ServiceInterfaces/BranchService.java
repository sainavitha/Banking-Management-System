package com.prasannareddy.BankingManagementSystemProjectUsingHibernate.ServiceInterfaces;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.Entites.Branch;
public interface BranchService {
	 void createBranch(Branch branch);
	    Branch readBranch(int branchId);
	    void updateBranch(Branch branch);
	    void deleteBranch(int branchId);
		Branch getBranchById(int branchId);
}
