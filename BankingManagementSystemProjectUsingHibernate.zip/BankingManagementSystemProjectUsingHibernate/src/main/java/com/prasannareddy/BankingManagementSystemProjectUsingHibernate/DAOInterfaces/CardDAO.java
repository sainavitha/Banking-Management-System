package com.prasannareddy.BankingManagementSystemProjectUsingHibernate.DAOInterfaces;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.Entites.Card;
public interface CardDAO {
	void createCard(Card card);
    Card readCard(int cardNumber);
    void updateCard(Card card);
    void deleteCard(int cardNumber);
}
