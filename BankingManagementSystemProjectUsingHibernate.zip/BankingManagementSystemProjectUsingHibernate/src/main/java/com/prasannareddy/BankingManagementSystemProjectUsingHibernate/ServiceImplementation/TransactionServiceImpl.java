package com.prasannareddy.BankingManagementSystemProjectUsingHibernate.ServiceImplementation;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.DAOImplementation.*;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.ServiceInterfaces.TransactionService;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.DAOInterfaces.*;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.Entites.Transaction;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.ServiceInterfaces.*;
public abstract class TransactionServiceImpl implements TransactionService {
    private TransactionDAO transactionDAO = new TransactionDAOImpl();
    @Override
    public void createTransaction(Transaction transaction) {
        transactionDAO.createTransaction(transaction);
    }
    @Override
    public Transaction readTransaction(int transactionId) {
        return transactionDAO.readTransaction(transactionId);
    }
    @Override
    public void updateTransaction(Transaction transaction) {
        transactionDAO.updateTransaction(transaction);
    }
    @Override
    public void deleteTransaction(int transactionId) {
        transactionDAO.deleteTransaction(transactionId);
    }
}

