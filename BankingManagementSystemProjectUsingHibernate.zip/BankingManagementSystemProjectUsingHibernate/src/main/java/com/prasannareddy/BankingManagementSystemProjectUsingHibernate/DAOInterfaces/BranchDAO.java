package com.prasannareddy.BankingManagementSystemProjectUsingHibernate.DAOInterfaces;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.Entites.Branch;
public interface BranchDAO {
	 void createBranch(Branch branch);
	    Branch readBranch(int branchId);
	    void updateBranch(Branch branch);
	    void deleteBranch(int branchId);
}
