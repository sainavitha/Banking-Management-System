package com.prasannareddy.BankingManagementSystemProjectUsingHibernate.ServiceInterfaces;
import java.util.List;

import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.Entites.Account;
public interface AccountService {
	void createAccount(Account account);
    Account readAccount(int accountNumber);
    void updateAccount(Account account);
    void deleteAccount(int accountNumber);
	List<Account> getAllAccounts();
	Account getAccountById(int accountNumber);
}
