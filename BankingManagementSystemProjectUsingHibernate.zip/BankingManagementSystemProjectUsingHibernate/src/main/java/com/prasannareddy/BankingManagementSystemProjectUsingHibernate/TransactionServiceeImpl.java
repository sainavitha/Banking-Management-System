package com.prasannareddy.BankingManagementSystemProjectUsingHibernate;

import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.Entites.Transaction;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.ServiceInterfaces.TransactionService;

public class TransactionServiceeImpl implements TransactionService {

	@Override
	public void createTransaction(Transaction transaction) {
		// TODO Auto-generated method stub

	}

	@Override
	public Transaction readTransaction(int transactionId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateTransaction(Transaction transaction) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteTransaction(int transactionId) {
		// TODO Auto-generated method stub

	}

	@Override
	public Transaction getTransactionById(int transactionId) {
		// TODO Auto-generated method stub
		return null;
	}

}
