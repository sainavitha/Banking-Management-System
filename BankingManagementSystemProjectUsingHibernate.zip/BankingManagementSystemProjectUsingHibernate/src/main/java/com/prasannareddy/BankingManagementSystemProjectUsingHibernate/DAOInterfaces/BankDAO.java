package com.prasannareddy.BankingManagementSystemProjectUsingHibernate.DAOInterfaces;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.Entites.Bank;
public interface BankDAO {
	 void createBank(Bank bank);
	    Bank readBank(int bankCode);
	    void updateBank(Bank bank);
	    void deleteBank(int bankCode);
}
