package com.prasannareddy.BankingManagementSystemProjectUsingHibernate;

import java.util.List;

import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.Entites.Bank;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.ServiceInterfaces.BankService;

public class BankServiceeImpl implements BankService {

	@Override
	public void createBank(Bank bank) {
		// TODO Auto-generated method stub

	}

	@Override
	public Bank readBank(int bankCode) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateBank(Bank bank) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteBank(int bankCode) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<Bank> getAllBanks() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Bank getBank(int bankCode) {
		// TODO Auto-generated method stub
		return null;
	}

}
