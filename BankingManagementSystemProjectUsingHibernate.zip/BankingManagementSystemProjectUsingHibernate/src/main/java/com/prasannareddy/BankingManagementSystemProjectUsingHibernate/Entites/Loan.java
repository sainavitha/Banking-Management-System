package com.prasannareddy.BankingManagementSystemProjectUsingHibernate.Entites;
import jakarta.persistence.*;
@Entity
@Table(name = "Loan")
public class Loan {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int loanId;
    private double loanAmount;
    private double interestRate;
    private int tenure; // in months
    private int customerId;

    // Getters and Setters
    public int getLoanId() {
        return loanId;
    }
    public void setLoanId(int LoanId) {
      this.loanId = LoanId;
    }
    public double getLoanAmount() {
        return loanAmount;
    }
    public void setLoanAmount(int loanType) {
        this.loanAmount = loanType;
    }
    public double getInterestRate() {
        return interestRate;
    }
    public void setInterestRate(double interestRate) {
        this.interestRate = interestRate;
    }
    public int getTenure() {
        return tenure;
    }
    public void setTenure(int tenure) {
        this.tenure = tenure;
    }
    public int getCustomerId() {
        return customerId;
    }
    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }
	public void setLoanAmount(double loanAmount2) {
		// TODO Auto-generated method stub
		
	}
}