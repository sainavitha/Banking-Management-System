package com.prasannareddy.BankingManagementSystemProjectUsingHibernate.ServiceInterfaces;
import java.util.List;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.Entites.Card;
public interface CardService {
	void createCard(Card card);
    Card readCard(int cardNumber);
    void updateCard(Card card);
    void deleteCard(int cardNumber);
	List<Card> getAllCards();
	Card getCardById(int cardNumber);	 
}
