package com.prasannareddy.BankingManagementSystemProjectUsingHibernate.DAOInterfaces;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.Entites.Transaction;
public interface TransactionDAO {
	    void createTransaction(Transaction transaction);
	    Transaction readTransaction(int transactionId);
	    void updateTransaction(Transaction transaction);
	    void deleteTransaction(int transactionId);
}
