package com.prasannareddy.BankingManagementSystemProjectUsingHibernate.DAOImplementation;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.HibernateUtil;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.DAOInterfaces.AccountDAO;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.Entites.Account;
public class AccountDAOImpl implements AccountDAO {
    @Override
    public void createAccount(Account account) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.save(account);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }
    @Override
    public Account readAccount(int accountNumber) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.get(Account.class, accountNumber);
        }
    }
    @Override
    public void updateAccount(Account account) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.update(account);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }
    @Override
    public void deleteAccount(int accountNumber) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            Account account = session.get(Account.class, accountNumber);
            if (account != null) {
                session.delete(account);
            }
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }
}
