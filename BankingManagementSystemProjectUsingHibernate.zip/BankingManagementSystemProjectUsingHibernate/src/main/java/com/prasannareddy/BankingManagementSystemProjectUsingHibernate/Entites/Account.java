package com.prasannareddy.BankingManagementSystemProjectUsingHibernate.Entites;
import jakarta.persistence.*;
@Entity
@Table(name = "Account")
public class Account {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int accountNumber;
    private String accountType;
    private double balance;
    private int customerId;
    private java.sql.Date dateOfOpened;
 // Getters and Setters
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public java.sql.Date getDateOfOpened() {
		return dateOfOpened;
	}
	public void setDateOfOpened(java.sql.Date dateOfOpened) {
		this.dateOfOpened = dateOfOpened;
	}
    
}
