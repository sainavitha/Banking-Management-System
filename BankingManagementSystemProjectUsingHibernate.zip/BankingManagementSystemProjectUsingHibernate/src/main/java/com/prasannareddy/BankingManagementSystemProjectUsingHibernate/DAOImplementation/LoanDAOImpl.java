package com.prasannareddy.BankingManagementSystemProjectUsingHibernate.DAOImplementation;
import org.hibernate.Session;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.HibernateUtil;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.DAOInterfaces.LoanDAO;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.Entites.Loan;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.Entites.Transaction;
import jakarta.persistence.EntityTransaction;

import java.util.List;

public abstract class LoanDAOImpl implements LoanDAO {

    @Override
    public void createLoan(Loan loan) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = (Transaction) session.beginTransaction();
            session.save(loan);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                ((EntityTransaction) transaction).rollback();
            }
            e.printStackTrace();
        }
    }

    @Override
    public Loan getLoanById(int loanId) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.get(Loan.class, loanId);
        }
    }

    @Override
    public List<Loan> getAllLoans() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("from Loan", Loan.class).list();
        }
    }

    @Override
    public void updateLoan(Loan loan) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = (Transaction) session.beginTransaction();
            session.update(loan);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }

    @Override
    public void deleteLoan(int loanId) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = (Transaction) session.beginTransaction();
            Loan loan = session.get(Loan.class, loanId);
            if (loan != null) {
                session.delete(loan);
            }
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                ((EntityTransaction) transaction).rollback();
            }
            e.printStackTrace();
        }
    }
}