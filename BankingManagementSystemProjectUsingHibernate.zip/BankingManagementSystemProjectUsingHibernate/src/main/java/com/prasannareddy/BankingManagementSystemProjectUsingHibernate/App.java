package com.prasannareddy.BankingManagementSystemProjectUsingHibernate;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.Entites.*;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.ServiceImplementation.*;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.ServiceInterfaces.*;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.DAOInterfaces.*;
import java.util.Scanner;
public class App {
    private static SessionFactory sessionFactory;
    private static BankService bankService;
    private static BranchService branchService;
    private static AccountService accountService;
    private static CustomerService customerService;
    private static CardService cardService;
    private static LoanService loanService;
    private static TransactionService transactionService;
    private static EmployeeService employeeService;
    public static void main(String[] args) {
        try {
            // Initialize Hibernate SessionFactory
            sessionFactory = new Configuration().configure().buildSessionFactory();

            // Initialize services
            initializeServices();

            // Run main menu
            Scanner scanner = new Scanner(System.in);
            runMainMenu(scanner);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (sessionFactory != null) {
                sessionFactory.close();
            }
        }
    }

    private static void initializeServices() {
        bankService = new BankServiceImple();
        branchService = new BranchServiceImpl();
        accountService = new AccountServiceImpl();
        customerService = new CustomerServiceImpl();
        cardService = new CardServiceImple();
        loanService = new LoanServiceImple();
        transactionService = new TransactionServiceImple();
        employeeService = new EmployeeServiceImpls();
    }

    private static void runMainMenu(Scanner scanner) {
        while (true) {
            System.out.println("\n=== Banking Management System ===");
            System.out.println("1. Bank Operations");
            System.out.println("2. Branch Operations");
            System.out.println("3. Account Operations");
            System.out.println("4. Customer Operations");
            System.out.println("5. Card Operations");
            System.out.println("6. Loan Operations");
            System.out.println("7. Transaction Operations");
            System.out.println("8. Employee Operations");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    handleBankOperations(scanner);
                    break;
                case 2:
                    handleBranchOperations(scanner);
                    break;
                case 3:
                    handleAccountOperations(scanner);
                    break;
                case 4:
                    handleCustomerOperations(scanner);
                    break;
                case 5:
                    handleCardOperations(scanner);
                    break;
                case 6:
                    handleLoanOperations(scanner);
                    break;
                case 7:
                    handleTransactionOperations(scanner);
                    break;
                case 8:
                    handleEmployeeOperations(scanner);
                    break;
                case 0:
                    System.out.println("Thank you for using Banking Management System!");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    // Bank Operations
    private static void handleBankOperations(Scanner scanner) {
        while (true) {
            System.out.println("\n=== Bank Operations ===");
            System.out.println("1. Create Bank");
            System.out.println("2. Read Bank");
            System.out.println("3. Update Bank");
            System.out.println("4. Delete Bank");
            System.out.println("0. Back to Main Menu");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    createBank(scanner);
                    break;
                case 2:
                    readBank(scanner);
                    break;
                case 3:
                    updateBank(scanner);
                    break;
                case 4:
                    deleteBank(scanner);
                    break;
                case 0:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void createBank(Scanner scanner) {
        System.out.print("Enter bank code: ");
        int bankCode = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter bank name: ");
        String bankName = scanner.nextLine();

        Bank bank = new Bank();
        bank.setBankCode(bankCode);
        bank.setBankName(bankName);

        bankService.createBank(bank);
        System.out.println("Bank created successfully.");
    }

    private static void readBank(Scanner scanner) {
        System.out.print("Enter bank code to read: ");
        int bankCode = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Bank bank = bankService.readBank(bankCode);
        if (bank != null) {
            System.out.println("Bank details: " + bank);
        } else {
            System.out.println("Bank not found.");
        }
    }

   

	private static void updateBank(Scanner scanner) {
        System.out.print("Enter bank code to update: ");
        int bankCode = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Bank bank = bankService.readBank(bankCode);
        if (bank != null) {
            System.out.print("Enter new bank name (press enter to skip): ");
            String bankName = scanner.nextLine();
            if (!bankName.isEmpty()) {
                bank.setBankName(bankName);
            }

            bankService.updateBank(bank);
            System.out.println("Bank updated successfully.");
        } else {
            System.out.println("Bank not found.");
        }
    }

    private static void deleteBank(Scanner scanner) {
        System.out.print("Enter bank code to delete: ");
        int bankCode = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        bankService.deleteBank(bankCode);
        System.out.println("Bank deleted successfully.");
    }

    // Branch Operations
    private static void handleBranchOperations(Scanner scanner) {
        while (true) {
            System.out.println("\n=== Branch Operations ===");
            System.out.println("1. Create Branch");
            System.out.println("2. Read Branch");
            System.out.println("3. Update Branch");
            System.out.println("4. Delete Branch");
            System.out.println("0. Back to Main Menu");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    createBranch(scanner);
                    break;
                case 2:
                    readBranch(scanner);
                    break;
                case 3:
                    updateBranch(scanner);
                    break;
                case 4:
                    deleteBranch(scanner);
                    break;
                case 0:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void createBranch(Scanner scanner) {
        System.out.print("Enter branch ID: ");
        int branchId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter branch code: ");
        int branchCode = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter bank code: ");
        int bankCode = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter branch name: ");
        String branchName = scanner.nextLine();

        Branch branch = new Branch();
        branch.setBranchId(branchId);
        branch.setBranchCode(branchCode);
        branch.setBankCode(bankCode);
        branch.setBranchName(branchName);

        branchService.createBranch(branch);
        System.out.println("Branch created successfully.");
    }

    private static void readBranch(Scanner scanner) {
        System.out.print("Enter branch ID to read: ");
        int branchId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Branch branch = branchService.readBranch(branchId);
        if (branch != null) {
            System.out.println("Branch details: " + branch);
        } else {
            System.out.println("Branch not found.");
        }
    }

    private static void updateBranch(Scanner scanner) {
        System.out.print("Enter branch ID to update: ");
        int branchId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Branch branch = branchService.readBranch(branchId);
        if (branch != null) {
            System.out.print("Enter new branch name (press enter to skip): ");
            String branchName = scanner.nextLine();
            if (!branchName.isEmpty()) {
                branch.setBranchName(branchName);
            }

            branchService.updateBranch(branch);
            System.out.println("Branch updated successfully.");
        } else {
            System.out.println("Branch not found.");
        }
    }

    private static void deleteBranch(Scanner scanner) {
        System.out.print("Enter branch ID to delete: ");
        int branchId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        branchService.deleteBranch(branchId);
        System.out.println("Branch deleted successfully.");
    }

    // Account Operations
    private static void handleAccountOperations(Scanner scanner) {
        while (true) {
            System.out.println("\n=== Account Operations ===");
            System.out.println("1. Create Account");
            System.out.println("2. Read Account");
            System.out.println("3. Update Account");
            System.out.println("4. Delete Account");
            System.out.println("0. Back to Main Menu");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1 :
                    createAccount(scanner);
                    break;
                case 2:
                    readAccount(scanner);
                    break;
                case 3:
                    updateAccount(scanner);
                    break;
                case 4:
                    deleteAccount(scanner);
                    break;
                case 0:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void createAccount(Scanner scanner) {
        System.out.print("Enter account number: ");
        int accountNumber = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter account type: ");
        String accountType = scanner.nextLine();
        System.out.print("Enter balance: ");
        double balance = scanner.nextDouble();
        System.out.print("Enter customer ID: ");
        int customerId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter date of opened (yyyy-mm-dd): ");
        String dateOfOpened = scanner.nextLine();

        Account account = new Account();
        account.setAccountNumber(accountNumber);
        account.setAccountType(accountType);
        account.setBalance(balance);
        account.setCustomerId(customerId);
        account.setDateOfOpened(java.sql.Date.valueOf(dateOfOpened));

        accountService.createAccount(account);
        System.out.println("Account created successfully.");
    }

    private static void readAccount(Scanner scanner) {
        System.out.print("Enter account number to read: ");
        int accountNumber = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Account account = accountService.readAccount(accountNumber);
        if (account != null) {
            System.out.println("Account details: " + account);
        } else {
            System.out.println("Account not found.");
        }
    }

    private static void updateAccount(Scanner scanner) {
        System.out.print("Enter account number to update: ");
        int accountNumber = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Account account = accountService.readAccount(accountNumber);
        if (account != null) {
            System.out.print("Enter new account type (press enter to skip): ");
            String accountType = scanner.nextLine();
            if (!accountType.isEmpty()) {
                account.setAccountType(accountType);
            }

            System.out.print("Enter new balance (press enter to skip): ");
            String balanceInput = scanner.nextLine();
            if (!balanceInput.isEmpty()) {
                account.setBalance(Double.parseDouble(balanceInput));
            }

            accountService.updateAccount(account);
            System.out.println("Account updated successfully.");
        } else {
            System.out.println("Account not found.");
        }
    }

    private static void deleteAccount(Scanner scanner) {
        System.out.print("Enter account number to delete: ");
        int accountNumber = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        accountService.deleteAccount(accountNumber);
        System.out.println("Account deleted successfully.");
    }

    // Customer Operations
    private static void handleCustomerOperations(Scanner scanner) {
        while (true) {
            System.out.println("\n=== Customer Operations ===");
            System.out.println("1. Create Customer");
            System.out.println("2. Read Customer");
            System.out.println("3. Update Customer");
            System.out.println("4. Delete Customer");
            System.out.println("0. Back to Main Menu");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    createCustomer(scanner);
                    break;
                case 2:
                    readCustomer(scanner);
                    break;
                case 3:
                    updateCustomer(scanner);
                    break;
                case 4:
                    deleteCustomer(scanner);
                    break;
                case 0:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void createCustomer(Scanner scanner) {
        System.out.print("Enter customer ID: ");
        int customerId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter first name: ");
        String firstName = scanner.nextLine();
        System.out.print("Enter last name: ");
        String lastName = scanner.nextLine();
        System.out.print("Enter surname: ");
        String surname = scanner.nextLine();
        System.out.print("Enter address: ");
        String address = scanner.nextLine();
        System.out.print("Enter phone: ");
        String phone = scanner.nextLine();
        System.out.print("Enter email: ");
        String email = scanner.nextLine();

        Customer customer = new Customer();
        customer.setCustomerId(customerId);
        customer.setFirstName(firstName);
        customer.setLastName(lastName);
        customer.setSurname(surname);
        customer.setAddress(address);
        customer.setPhone(phone);
        customer.setEmail(email);

        customerService.createCustomer(customer);
        System.out.println("Customer created successfully.");
    }

    private static void readCustomer(Scanner scanner) {
        System.out.print("Enter customer ID to read: ");
        int customerId = scanner.nextInt();
        scanner .nextLine(); // Consume newline

        Customer customer = customerService.readCustomer(customerId);
        if (customer != null) {
            System.out.println("Customer details: " + customer);
        } else {
            System.out.println("Customer not found.");
        }
    }

    private static void updateCustomer(Scanner scanner) {
        System.out.print("Enter customer ID to update: ");
        int customerId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Customer customer = customerService.readCustomer(customerId);
        if (customer != null) {
            System.out.print("Enter new first name (press enter to skip): ");
            String firstName = scanner.nextLine();
            if (!firstName.isEmpty()) {
                customer.setFirstName(firstName);
            }

            System.out.print("Enter new last name (press enter to skip): ");
            String lastName = scanner.nextLine();
            if (!lastName.isEmpty()) {
                customer.setLastName(lastName);
            }

            customerService.updateCustomer(customer);
            System.out.println("Customer updated successfully.");
        } else {
            System.out.println("Customer not found.");
        }
    }

    private static void deleteCustomer(Scanner scanner) {
        System.out.print("Enter customer ID to delete: ");
        int customerId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        customerService.deleteCustomer(customerId);
        System.out.println("Customer deleted successfully.");
    }

    // Card Operations
    private static void handleCardOperations(Scanner scanner) {
        while (true) {
            System.out.println("\n=== Card Operations ===");
            System.out.println("1. Create Card");
            System.out.println("2. Read Card");
            System.out.println("3. Update Card");
            System.out.println("4. Delete Card");
            System.out.println("0. Back to Main Menu");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    createCard(scanner);
                    break;
                case 2:
                    readCard(scanner);
                    break;
                case 3:
                    updateCard(scanner);
                    break;
                case 4:
                    deleteCard(scanner);
                    break;
                case 0:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void createCard(Scanner scanner) {
        System.out.print("Enter card number: ");
        int cardNumber = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter card type: ");
        String cardType = scanner.nextLine();
        System.out.print("Enter CVV: ");
        int cvv = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter expiry date (yyyy-mm-dd): ");
        String expiryDate = scanner.nextLine();
        System.out.print("Enter customer ID: ");
        int customerId = scanner.nextInt();

        Card card = new Card();
        card.setCardNumber(cardNumber);
        card.setCardType(cardType);
        card.setCvv(cvv);
        card.setExpiryDate(java.sql.Date.valueOf(expiryDate));
        card.setCustomerId(customerId);

        cardService.createCard(card);
        System.out.println("Card created successfully.");
    }

    private static void readCard(Scanner scanner) {
        System.out.print("Enter card number to read: ");
        int cardNumber = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Card card = cardService.readCard(cardNumber);
        if (card != null) {
            System.out.println("Card details: " + card);
        } else {
            System.out.println("Card not found.");
        }
    }

    private static void updateCard(Scanner scanner) {
        System.out.print("Enter card number to update: ");
        int cardNumber = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Card card = cardService.readCard(cardNumber);
        if (card != null) {
            System.out.print("Enter new card type (press enter to skip): ");
            String cardType = scanner.nextLine();
            if (!cardType.isEmpty()) {
                card.setCardType(cardType);
            }

            System.out.print("Enter new CVV (press enter to skip): ");
            String cvvInput = scanner.nextLine();
            if (!cvvInput.isEmpty()) {
                card.setCvv(Integer.parseInt(cvvInput));
            }

            System.out.print("Enter new expiry date (yyyy-mm-dd) (press enter to skip): ");
            String expiryDateInput = scanner.nextLine();
            if (!expiryDateInput.isEmpty()) {
                card.setExpiryDate(java.sql.Date.valueOf(expiryDateInput));
            }

            cardService.updateCard(card);
            System.out.println("Card updated successfully.");
        } else {
            System.out.println("Card not found.");
        }
    }

    private static void deleteCard(Scanner scanner) {
        System.out.print("Enter card number to delete: ");
        int cardNumber = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        cardService.deleteCard(cardNumber);
        System.out.println("Card deleted successfully.");
    }

    // Loan Operations
    private static void handleLoanOperations(Scanner scanner) {
        while (true) {
            System.out.println("\n=== Loan Operations ===");
            System.out.println("1. Create Loan");
            System.out.println("2. Read Loan");
            System.out.println("3. Update Loan");
            System.out.println("4. Delete Loan");
            System.out.println("0. Back to Main Menu");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    createLoan(scanner);
                    break;
                case 2:
                    readLoan(scanner);
                    break;
                case 3:
                    updateLoan(scanner);
                    break;
                case 4:
                    deleteLoan(scanner);
                    break;
                case 0:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void createLoan(Scanner scanner) {
        System.out.print("Enter loan ID: ");
        int loanId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter loan amount: ");
         double loanAmount = scanner.nextDouble();
        System.out.print("Enter interest rate: ");
        double interestRate = scanner.nextDouble();
        System.out.print("Enter tenure (in months): ");
        int tenure = scanner.nextInt();
        System.out.print("Enter customer ID: ");
        int customerId = scanner.nextInt();

        Loan loan = new Loan();
        loan.setLoanId(loanId);
        loan.setLoanAmount(loanAmount);
        loan.setInterestRate(interestRate);
        loan.setTenure(tenure);
        loan.setCustomerId(customerId);

        loanService.createLoan(loan);
        System.out.println("Loan created successfully.");
    }

    private static void readLoan(Scanner scanner) {
        System.out.print("Enter loan ID to read: ");
        int loanId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Loan loan = loanService.readLoan(loanId);
        if (loan != null) {
            System.out.println("Loan details: " + loan);
        } else {
            System.out.println("Loan not found.");
        }
    }

    private static void updateLoan(Scanner scanner) {
        System.out.print("Enter loan ID to update: ");
        int loanId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Loan loan = loanService.readLoan(loanId);
        if (loan != null) {
            System.out.print("Enter new loan amount (press enter to skip): ");
            String loanAmountInput = scanner.nextLine();
            if (!loanAmountInput.isEmpty()) {
                loan.setLoanAmount(Double.parseDouble(loanAmountInput));
            }

            System.out.print("Enter new interest rate (press enter to skip): ");
            String interestRateInput = scanner.nextLine();
            if (!interestRateInput.isEmpty()) {
                loan.setInterestRate(Double.parseDouble(interestRateInput));
            }

            System.out.print("Enter new tenure (press enter to skip): ");
            String tenureInput = scanner.nextLine();
            if (!tenureInput.isEmpty()) {
                loan.setTenure(Integer.parseInt(tenureInput));
            }

            loanService.updateLoan(loan);
            System.out.println("Loan updated successfully.");
        } else {
            System.out.println("Loan not found.");
        }
    }

    private static void deleteLoan(Scanner scanner) {
        System.out.print("Enter loan ID to delete: ");
        int loanId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        loanService.deleteLoan(loanId);
        System.out.println("Loan deleted successfully.");
    }

    // Transaction Operations
    private static void handleTransactionOperations(Scanner scanner) {
        while (true) {
            System.out.println("\n=== Transaction Operations ===");
            System.out.println("1. Create Transaction");
            System.out.println("2. Read Transaction");
            System.out.println("3. Update Transaction");
            System.out.println("4. Delete Transaction");
            System.out.println("0. Back to Main Menu");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    createTransaction(scanner);
                    break;
                case 2:
                    readTransaction(scanner);
                    break;
                case 3:
                    updateTransaction(scanner);
                    break;
                case 4:
                    deleteTransaction(scanner);
                    break;
                case 0:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void createTransaction(Scanner scanner) {
        System.out.print("Enter transaction ID: ");
        int transactionId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter transaction date (yyyy-mm-dd): ");
        String transactionDateInput = scanner.nextLine();
        System.out.print("Enter transaction type: ");
        String transactionType = scanner.nextLine();
        System.out.print("Enter amount: ");
        double amount = scanner.nextDouble();
        System.out.print("Enter account number: ");
        int accountNumber = scanner.nextInt();
        System.out.print("Enter branch code: ");
        int branchCode = scanner.nextInt();

        Transaction transaction = new Transaction();
        transaction.setTransactionId(transactionId);
        transaction.setTransactionDate(java.sql.Date.valueOf(transactionDateInput));
        transaction.setTransactionType(transactionType);
        transaction.setAmount(amount);
        transaction.setAccountNumber(accountNumber);
        transaction.setBranchCode(branchCode);

        transactionService.createTransaction(transaction);
        System.out.println("Transaction created successfully.");
    }

    private static void readTransaction(Scanner scanner) {
        System.out.print("Enter transaction ID to read: ");
        int transactionId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Transaction transaction = transactionService.readTransaction(transactionId);
        if (transaction != null) {
            System.out.println("Transaction details: " + transaction);
        } else {
            System.out.println("Transaction not found.");
        }
    }

    private static void updateTransaction(Scanner scanner) {
        System.out.print("Enter transaction ID to update: ");
        int transactionId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Transaction transaction = transactionService.readTransaction(transactionId);
        if (transaction != null) {
            System.out.print("Enter new transaction date (yyyy-mm-dd) (press enter to skip): ");
            String transactionDateInput = scanner.nextLine();
            if (!transactionDateInput.isEmpty()) {
                transaction.setTransactionDate(java.sql.Date.valueOf(transactionDateInput));
            }

            System.out.print("Enter new transaction type (press enter to skip): ");
            String transactionType = scanner.nextLine();
            if (!transactionType.isEmpty()) {
                transaction.setTransactionType(transactionType);
            }

            System.out.print("Enter new amount (press enter to skip): ");
            String amountInput = scanner.nextLine();
            if (!amountInput.isEmpty()) {
                transaction.setAmount(Double.parseDouble(amountInput));
            }

            transactionService.updateTransaction(transaction);
            System.out.println("Transaction updated successfully.");
        } else {
            System.out.println("Transaction not found.");
        }
    }

    private static void deleteTransaction(Scanner scanner) {
        System.out.print("Enter transaction ID to delete: ");
        int transactionId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        transactionService.deleteTransaction(transactionId);
        System.out.println("Transaction deleted successfully.");
    }

    // Employee Operations
    private static void handleEmployeeOperations(Scanner scanner) {
        while (true) {
            System.out.println("\n=== Employee Operations ===");
            System.out.println("1. Create Employee");
            System.out.println("2. Read Employee");
            System.out.println("3. Update Employee");
            System.out.println("4. Delete Employee");
            System.out.println("0. Back to Main Menu");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    createEmployee(scanner);
                    break;
                case 2:
                    readEmployee(scanner);
                    break;
                case 3:
                    updateEmployee(scanner);
                    break;
                case 4:
                    deleteEmployee(scanner);
                    break;
                case 0:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void createEmployee(Scanner scanner) {
        System.out.print("Enter employee ID: ");
        int employeeId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter employee name: ");
        String name = scanner.nextLine();
        System.out.print("Enter position: ");
        String position = scanner.nextLine();
        System.out.print("Enter salary: ");
        double salary = scanner.nextDouble();
        System.out.print("Enter branch code: ");
        int branchCode = scanner.nextInt();

        Employee employee = new Employee();
        employee.setEmployeeId(employeeId);
        employee.setName(name);
        employee.setPosition(position);
        employee.setSalary(salary);
        employee.setBranchCode(branchCode);

        employeeService.createEmployee(employee);
        System.out.println("Employee created successfully.");
    }

    private static void readEmployee(Scanner scanner) {
        System.out.print("Enter employee ID to read: ");
        int employeeId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Employee employee = employeeService.readEmployee(employeeId);
        if (employee != null) {
            System.out.println("Employee details: " + employee);
        } else {
            System.out.println("Employee not found.");
        }
    }

    private static void updateEmployee(Scanner scanner) {
        System.out.print("Enter employee ID to update: ");
        int employeeId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Employee employee = employeeService.readEmployee(employeeId);
        if (employee != null) {
            System.out.print("Enter new name (press enter to skip): ");
            String name = scanner.nextLine();
            if (!name.isEmpty()) {
                employee.setName(name);
            }

            System.out.print("Enter new position (press enter to skip): ");
            String position = scanner.nextLine();
            if (!position.isEmpty()) {
                employee.setPosition(position);
            }

            System.out.print("Enter new salary (press enter to skip): ");
            String salaryInput = scanner.nextLine();
            if (!salaryInput.isEmpty()) {
                employee.setSalary(Double.parseDouble(salaryInput));
            }

            System.out.print("Enter new branch code (press enter to skip): ");
            String branchCodeInput = scanner.nextLine();
            if (!branchCodeInput.isEmpty()) {
                employee.setBranchCode(Integer.parseInt(branchCodeInput));
            }

            employeeService.updateEmployee(employee);
            System.out.println("Employee updated successfully.");
        } else {
            System.out.println("Employee not found.");
        }
    }

    private static void deleteEmployee(Scanner scanner) {
        System.out.print("Enter employee ID to delete: ");
        int employeeId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        employeeService.deleteEmployee(employeeId);
        System.out.println("Employee deleted successfully.");
    }
}