package com.prasannareddy.BankingManagementSystemProjectUsingHibernate.ServiceImplementation;
import java.util.List;

import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.DAOImplementation.*;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.Entites.Account;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.ServiceInterfaces.AccountService;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.DAOInterfaces.*;
public class AccountServiceImpl implements AccountService {
    private AccountDAO accountDAO = new AccountDAOImpl();
    @Override
    public void createAccount(Account account) {
        accountDAO.createAccount(account);
    }
    @Override
    public Account readAccount(int accountNumber) {
        return accountDAO.readAccount(accountNumber);
    }
    @Override
    public void updateAccount(Account account) {
        accountDAO.updateAccount(account);
    }
    @Override
    public void deleteAccount(int accountNumber) {
        accountDAO.deleteAccount(accountNumber);
    }
	@Override
	public List<Account> getAllAccounts() {
		// TODO Auto-generated method stub
		return null;
	}
	public Account getAccountById(int updateId) {
		// TODO Auto-generated method stub
		return null;
	}
}
