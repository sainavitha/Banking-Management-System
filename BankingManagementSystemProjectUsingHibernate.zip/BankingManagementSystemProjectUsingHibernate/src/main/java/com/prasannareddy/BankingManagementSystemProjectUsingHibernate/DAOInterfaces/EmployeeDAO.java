package com.prasannareddy.BankingManagementSystemProjectUsingHibernate.DAOInterfaces;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.Entites.Employee;
public interface EmployeeDAO {
	void createEmployee(Employee employee);
    Employee readEmployee(int employeeId);
    void updateEmployee(Employee employee);
    void deleteEmployee(int employeeId);
}

