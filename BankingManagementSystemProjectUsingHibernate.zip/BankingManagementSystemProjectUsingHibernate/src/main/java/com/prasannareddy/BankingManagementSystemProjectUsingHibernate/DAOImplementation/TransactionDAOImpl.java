package com.prasannareddy.BankingManagementSystemProjectUsingHibernate.DAOImplementation;
import org.hibernate.Session;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.HibernateUtil;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.DAOInterfaces.TransactionDAO;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.Entites.*;
public class TransactionDAOImpl implements TransactionDAO {
    @Override
    public void createTransaction(Transaction transaction) {
        org.hibernate.Transaction transactionHibernate = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transactionHibernate = session.beginTransaction();
            session.save(transaction);
            transactionHibernate.commit();
        } catch (Exception e) {
            if (transactionHibernate != null) {
                transactionHibernate.rollback();
            }
            e.printStackTrace();
        }
    }
    @Override
    public Transaction readTransaction(int transactionId) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.get(Transaction.class, transactionId);
        }
    }

    @Override
    public void updateTransaction(Transaction transaction) {
        org.hibernate.Transaction transactionHibernate = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transactionHibernate = session.beginTransaction();
            session.update(transaction);
            transactionHibernate.commit();
        } catch (Exception e) {
            if (transactionHibernate != null) {
                transactionHibernate.rollback();
            }
            e.printStackTrace();
        }
    }
    @Override
    public void deleteTransaction(int transactionId) {
        org.hibernate.Transaction transactionHibernate = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transactionHibernate = session.beginTransaction();
            Transaction transactionToDelete = session.get(Transaction.class, transactionId);
            if (transactionToDelete != null) {
                session.delete(transactionToDelete);
            }
            transactionHibernate.commit();
        } catch (Exception e) {
            if (transactionHibernate != null) {
                transactionHibernate.rollback();
            }
            e.printStackTrace();
        }
    }
}
