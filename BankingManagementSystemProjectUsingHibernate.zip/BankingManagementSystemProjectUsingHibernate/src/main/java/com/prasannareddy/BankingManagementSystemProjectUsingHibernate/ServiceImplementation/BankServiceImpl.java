package com.prasannareddy.BankingManagementSystemProjectUsingHibernate.ServiceImplementation;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.DAOImplementation.BankDAOImpl;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.Entites.Bank;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.ServiceInterfaces.BankService;
public abstract class BankServiceImpl implements BankService {
    private BankDAOImpl bankDAO = new BankDAOImpl();
    @Override
    public void createBank(Bank bank) {
        bankDAO.createBank(bank);
    }
    @Override
    public Bank readBank(int bankCode) {
        return bankDAO.readBank(bankCode);
    }
    @Override
    public void updateBank(Bank bank) {
        bankDAO.updateBank(bank);
    }
    @Override
    public void deleteBank(int bankCode) {
        bankDAO.deleteBank(bankCode);
    }
}
