package com.prasannareddy.BankingManagementSystemProjectUsingHibernate;

import java.util.List;

import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.Entites.Employee;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.ServiceInterfaces.EmployeeService;

public class EmployeeServiceeImpl implements EmployeeService {

	@Override
	public void createEmployee(Employee employee) {
		// TODO Auto-generated method stub

	}

	@Override
	public Employee readEmployee(int employeeId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateEmployee(Employee employee) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteEmployee(int employeeId) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee getEmployeeById(int employeeId) {
		// TODO Auto-generated method stub
		return null;
	}

}
